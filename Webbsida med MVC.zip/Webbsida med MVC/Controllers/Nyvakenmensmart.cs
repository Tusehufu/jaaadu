﻿using Microsoft.AspNetCore.Mvc;
using Inlämningsuppgift1_Webbsida_med_MVC.Models;
using Microsoft.EntityFrameworkCore;

namespace Inlämningsuppgift1_Webbsida_med_MVC.Controllers
{
    public class Nyvakenmensmart : Controller
    {
        private readonly ApplicationDbContext _context;

        public Nyvakenmensmart(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            // Fetch courses from the database
            var coursesFromDatabase = _context.Courses.ToList();

            return View(coursesFromDatabase);
        }

    }
}