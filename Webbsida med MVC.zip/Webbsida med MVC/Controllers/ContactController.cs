﻿using Microsoft.AspNetCore.Mvc;

namespace Inlämningsuppgift1_Webbsida_med_MVC.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
