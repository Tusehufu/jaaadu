﻿using Inlämningsuppgift1_Webbsida_med_MVC.Models;
using Microsoft.AspNetCore.Mvc;

public class UserController : Controller
{
    private readonly ApplicationDbContext _context; // Replace YourDbContext with your actual DbContext

    public UserController(ApplicationDbContext context)
    {
      _context = context;
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public ActionResult Register(StudentViewModel student)
    {
        if (ModelState.IsValid)
        {
            // Check if the user is a student before allowing registration
            //if (!IsStudent(student))
            //{
            //    ModelState.AddModelError(string.Empty, "Only students are allowed to register.");
            //    return View("SignupForm", student);
            //}

            // Save the student to the database using your custom DbContext
            var newStudent = new Student
            {
                FirstName = student.FirstName,
                LastName = student.LastName,
                Email = student.Email,
                Password = student.Password, // Note: Securely hash and salt the password before saving
                StudentId = student.StudentId,
                GradeLevel = student.GradeLevel
                // Add any other student-specific properties
            };

            // Add the new student to the Students DbSet (assuming you have DbSet<Student> in your DbContext)
            _context.Students.Add(newStudent);

            // Save changes to the database
            _context.SaveChanges();

            // Redirect to a success page or do whatever you need
            return RedirectToAction("RegistrationSuccess");
        }

        // If the model state is not valid, redisplay the form
        return View("SignupForm", student);
    }

    private bool IsStudent(StudentViewModel student)
    {
        // You can implement logic here to determine if the user is a student
        // For example, you may check if the StudentId is not empty
        return !string.IsNullOrEmpty(student.StudentId);
    }

    public ActionResult RegistrationSuccess()
    {
        // Display a success page or redirect to a different page
        return View();
    }
}
