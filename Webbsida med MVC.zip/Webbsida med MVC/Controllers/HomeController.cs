﻿using Microsoft.AspNetCore.Mvc;

namespace Inlämningsuppgift1_Webbsida_med_MVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
