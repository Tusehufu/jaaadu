using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Inlämningsuppgift1_Webbsida_med_MVC.Views.Login
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
