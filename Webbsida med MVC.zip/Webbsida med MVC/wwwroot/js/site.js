﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

// JavaScript to show the modal
document.addEventListener('DOMContentLoaded', function () {
    var registrationLink = document.querySelector('.registration-link');
    var registrationModal = new bootstrap.Modal(document.getElementById('registrationModal'));

    registrationLink.addEventListener('click', function () {
        registrationModal.show();
    });
});