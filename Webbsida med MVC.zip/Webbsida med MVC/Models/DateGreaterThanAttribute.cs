﻿using System.ComponentModel.DataAnnotations;

namespace Inlämningsuppgift1_Webbsida_med_MVC.Models
{
    public class DateGreaterThanAttribute : ValidationAttribute
    {
            private readonly string _comparisonProperty;

    public DateGreaterThanAttribute(string comparisonProperty)
    {
        _comparisonProperty = comparisonProperty;
    }

    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        var startDateProperty = validationContext.ObjectType.GetProperty(_comparisonProperty);

        if (startDateProperty == null)
        {
            return new ValidationResult($"Unknown property: {_comparisonProperty}");
        }

        var startDate = (DateTime)startDateProperty.GetValue(validationContext.ObjectInstance);
        var endDate = (DateTime)value;

        if (endDate <= startDate)
        {
            return new ValidationResult(ErrorMessage ?? "End date must be greater than Start date");
        }

        return ValidationResult.Success;
    }
    }
}
