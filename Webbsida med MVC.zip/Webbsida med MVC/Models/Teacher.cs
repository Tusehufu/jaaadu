﻿namespace Inlämningsuppgift1_Webbsida_med_MVC.Models
{
    public class Teacher : User
    {
        public string TeacherId { get; set; }
        public string Subject { get; set; }

    }
}
