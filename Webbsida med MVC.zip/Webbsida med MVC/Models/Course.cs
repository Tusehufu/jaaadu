﻿using System.ComponentModel.DataAnnotations;

namespace Inlämningsuppgift1_Webbsida_med_MVC.Models
{
    public class Course
    {
        public int Id { get; set; }
        [Display(Name = "Kurstitel")]
        [Required(ErrorMessage = "Kursnamn krävs")]
        [StringLength(50, ErrorMessage = "Kursnamnet får max vara 50 tecken långt")]
        public string Name { get; set;}

        [Display(Name = "Beskrivning")]
        [StringLength(500, ErrorMessage = "Beskrivningen får max vara 500 tecken långt")]
        public string Description { get; set; }

        [Display(Name = "Startdatum")]
        [Required(ErrorMessage = "Startdatum krävs")]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [Display(Name = "Slutdatum")]
        [Required(ErrorMessage = "Slutdatum krävs")]
        [DataType(DataType.Date)]
        [DateGreaterThan("StartDate", ErrorMessage = "Slutdatum måste komma efter startdatumet")]
        public DateTime EndDate { get; set; }
    }
}
