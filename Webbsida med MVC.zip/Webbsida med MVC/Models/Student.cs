﻿namespace Inlämningsuppgift1_Webbsida_med_MVC.Models
{
    public class Student : User
    {
        public string StudentId { get; set; }
        public int GradeLevel { get; set; }
    }
}
