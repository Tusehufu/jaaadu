﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Inlämningsuppgift1_Webbsida_med_MVC.Models
{
    public class StudentViewModel
    {
        [Required(ErrorMessage = "First Name is required")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        // Add additional properties specific to student registration if needed
        [Required(ErrorMessage = "Student ID is required")]
        public string StudentId { get; set; }

        [Required(ErrorMessage = "Grade Level is required")]
        public int GradeLevel { get; set; }
    }
}
