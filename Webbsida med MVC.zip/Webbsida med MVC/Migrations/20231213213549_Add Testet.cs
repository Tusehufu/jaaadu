﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Inlämningsuppgift1_Webbsida_med_MVC.Migrations
{
    /// <inheritdoc />
    public partial class AddTestet : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
