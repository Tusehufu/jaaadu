﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace Inlämningsuppgift1_Webbsida_med_MVC.Areas.Identity.Data;

// Add profile data for application users by adding properties to the Inlämningsuppgift1_Webbsida_med_MVCUser class
public class Inlämningsuppgift1_Webbsida_med_MVCUser : IdentityUser
{
}

